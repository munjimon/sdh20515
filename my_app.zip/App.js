import React, { Component } from 'react';
import './App.css';
import Movie from './Movie'

const movies = [
    "강철비",
    "스타워즈",
    "신과함께",
    "저스티스리그"
]

const movieimage = [
    "http://img.insight.co.kr/static/2017/10/12/700/hge641w96z8rn74dp4nw.jpg",
    "http://t1.daumcdn.net/movie/469c5c4957bee98cabe85e04e630f174dc0b7670",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdm7GkGYFsdz6Vhmh6oSY6NhU8i14I9bWgV-qMTj0obv1O49Bd",
    "https://i.ytimg.com/vi/p3H6G3KJTL8/maxresdefault.jpg"
]

class App extends Component {
  render() {
    return (
      <div className="App">
          <Movie title={movies[0]} poster={movieimage[0]}/>
          <Movie title={movies[1]} poster={movieimage[1]}/>
          <Movie title={movies[2]} poster={movieimage[2]}/>
          <Movie title={movies[3]} poster={movieimage[3]}/>
      </div>
    );
  }
}

export default App;
